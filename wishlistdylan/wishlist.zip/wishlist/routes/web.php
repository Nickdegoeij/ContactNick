<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});
Route::get('/wishlist', 'WishlistController@index');

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/wish', 'WishlistController@grud')->name('grud');
Route::get('/wish/deletewish/{id}','WishlistController@deletewish')->name('deletewish');
Route::get('/wish/editwish/{id}','WishlistController@editwish')->name('editwish');
Route::post('/wish/editwishpost/{id}','WishlistController@editwishpost')->name('editwishpost');
Route::get('/wish/addwish','WishlistController@addwish')->name('addwish');
Route::post('wish/addwishpost','WishlistController@addwishpost')->name('addwishpost');



